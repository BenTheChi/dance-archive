const express = require('express')
const router = new express.Router()
const Competition = require('../models/competition')
const Category = require('../models/category')

//Create a new category under a specific competition
router.post('/competitions/:compName-:city-:date', async (req, res) => {
    const publicCategory = req.body
    publicCategory.date = new Date(req.params.date.replace(/%20/g," "))
    publicCategory.city = req.params.city

    const user = req.user
    const privateCategory = publicCategory

    try {
        const competition = await Competition.findOne({ name, date, city })

        if(!competition){
            return res.status(404).send()
        }
        else{
            privateCategory.competition = competition._id
            privateCategory.addedBy = user._id
            finalPrivateCategory = new Category(privateCategory)

            await finalPrivateCompetition.save()

            if(user.admin){
                res.status(201).send(privateCategory)
            }
            else{
                publicCategory.competition = req.params.compName
                res.status(201).send(publicCategory)
            }
        }
    } catch(e) {
        console.log(e)
        res.status(400).send(e.errors)
    }
})

router.get('/competitions/:compName-:city-:date/:catName', async (req, res) => {
    try {

    } catch(e) {

    }
})

router.patch('/competitions/:compName-:city-:date/:catName', async (req, res) => {
    try {

    } catch(e) {

    }
})

router.delete('/competitions/:compName-:city-:date/:catName', async (req, res) => {
    try {

    } catch(e) {

    }
})

module.exports = router