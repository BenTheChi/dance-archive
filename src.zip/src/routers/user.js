const express = require('express')
const router = new express.Router()
const User = require('../models/user')
const auth = require('../middleware/auth')
const validUpdates = require('../middleware/validUpdates')

router.post('/users', async (req, res) => {
    const userName = req.body.userName
    const email = req.body.email

    try {
        await User.findOne({ $or: [{ email },{ userName }] }, '_id').exec( async (err, user) => {
            if(error){
                res.status(500).send("Server Error.")
            }
            if(user){
                res.status(409).send("Username or Email aleady exists")
            }
            else{
                user = new User(req.body)
                await user.save().catch((error) => { res.status(400).send(error.errors)})
                const token = await user.generateAuthToken()
                res.status(201).send({user, token})
            }
        })

    } catch(error) {
        res.status(400).send(error)
    }
})
 
router.post('/users/login', async (req, res) => {
    try {
        const user = await User.findByCredentials(req.body.email, req.body.userName, req.body.password)
        const token = await user.generateAuthToken()
        res.send({user: user.getPublicProfile(), token})
    } catch (e) {
        res.status(400).send()
    }
})

router.post('/users/logout', auth, async (req, res) => {
    try {
        req.user.tokens = req.user.tokens.filter((token) => {
            return token.token !== req.token
        })
        await req.user.save()

        res.send()
    } catch (e) {
        res.status(500).send()
    }
})

router.post('/users/logoutAll', auth, async (req, res) => {
    try {
        req.user.tokens = []
        await req.user.save()
        res.send()
    } catch (e) {
        res.status(500).send()
    }
})

router.get('/users/me', auth, async (req, res) => {
    res.send(req.user)
})

//TODO Gets all users.  Queryable.  Admins only.
router.get('/users', auth, async (req, res) => {
    if(!req.isAdmin){
        res.status(403).send()
    }

    try {
        const users = await User.find()
        return res.status(200).send(users)
    } catch (error) {
        
    }
})

router.patch('/users/me', validUpdates, auth, async (req, res) => {
    try {
        req.updates.forEach((update) => req.user[update] = req.body[update])

        await req.user.save()
        
        res.send(req.user)
    } catch (e) {
        res.status(400).send(e)
    }
})

router.delete('/users/me', auth, async (req, res) => {
    try {
        await req.user.remove()
        res.send(req.user)
    } catch (e) {
        res.status(500).send()
    }
})

module.exports = router