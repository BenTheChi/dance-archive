const express = require('express')
const router = new express.Router()
const Competition = require('../models/competition')
const auth = require('../middleware/auth')
const validUpdates = require('../middleware/validUpdates')

//Create new competitions
router.post('/competitions', auth, async (req, res) => {
    const user = req.user
    var competition = new Competition(req.body)

    if(!user){
        res.status(401).send()
    }

    try {
        await Competition.findOne({name: req.body.name}).exec( async (error, existingCompetition) => {
            if(error){
                res.status(500).send("Server Error.")
            }
            if(existingCompetition){
                res.status(409).send("Competition by the same name aleady exists")
            }
            else{
                req.body.addedBy = user._id

                await competition.save()
                .catch((error) => {
                    res.status(400).send(error.errors)
                })

                if(req.isAdmin){
                    res.status(201).send(competition)
                }
            
                else{
                    res.status(201).send(req.body)
                }
            }
        })
        
    }
    catch(e){
        //Add better error handling with the getObjectValue script
        res.status(400).send(e)
    }
})

//Create new competitions in a city
router.post('/competitions/:city', auth, async (req, res) => {
    const user = req.user
    var competition = new Competition(req.body)

    if(!user){
        res.status(401).send()
    }

    try {
        competition.addedBy = user._id
        competition.city = req.params.city
        await competition.save()

        if(req.isAdmin){
            res.status(201).send(competition)
        }
    
        else{
            res.status(201).send(req.body)
        }
    }
    catch(e){
        //Add better error handling with the getObjectValue script
        res.status(400).send(e)
    }
})

//Should have some logic here for queries and pagination
router.get('/competitions', auth, async (req, res) => {
    var competitions

    try {
        if(req.isAdmin){
            competitions = await Competition.find().skip(req.query.skip).limit(req.query.limit)
        }
        else{
            competitions = await Competition.find({}, 'name date city dj mc series').skip(req.query.skip).limit(req.query.limit)
        }

        if(!competitions){
            return res.status(404).send()
        }
        else{
            console.log(competitions)
            return res.status(200).send(competitions)
        }
    } catch (error) {
        console.log(error)
        res.status(400).send()
    }
})

router.get('/competitions/:city/:name', auth, async (req, res) => {
    var competitions
    const name = req.params.name.replace(/-/g, " ")
    const city = req.params.city

    try {
        if(req.isAdmin){
            competitions = await Competition.findOne({ name, city })
        }
        else{
            competitions = await Competition.findOne({ name, city }, 'name date city dj mc series')
        }

        if(!competitions){
            return res.status(404).send()
        }
        else{
            return res.status(200).send(competitions)
        }
    } catch (error) {
        console.log(error)
        res.status(400).send()
    }
})

router.patch('/competitions/:city/:name', validUpdates, auth, async (req, res) => {
    const user = req.user
    const name = req.params.name
    const city = req.params.city

    if(!user){
        res.status(401).send()
    }

    try {
        const competition = await Competition.findOne({ name, city })
    
        if(!competition){
            return res.status(404).send()
        }
        
        if(!req.isAdmin){
            if(competition.addedBy != user._id){
                return res.status(403).send()
            }
        }

        //Update each field and convert Date if given
        req.updates.forEach((update) => competition[update] = req.body[update])
        if(req.body.date){
            competition.date = new Date(req.body.date)
        }

        await competition.save()

        res.send(competition)
    } catch(errors) {
        console.log(errors)
        res.status(400).send()
    }
})

router.delete('/competitions/:city/:name', auth, async (req, res) => {
    const user = req.user 
    const name = req.params.name
    const city = req.params.city

    if(!user){
        res.status(401).send()
    }

    try {
        const competition = await Competition.findOneAndDelete({ name, city })

        if(!competition){
            res.status(404).send()
        }
        
        if(!req.isAdmin || competition.addedBy != user._id){
            res.status(403).send()
        }

        if(!competition){
            res.status(404).send("Cannot find this competition to delete")
        }

        res.send(competition)
    } catch(error) {
        console.log(error)
        res.status(400).send()
    }
})

module.exports = router