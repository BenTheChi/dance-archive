const express = require('express')
const router = new express.Router()
const Series = require('../models/series')
const auth = require('../middleware/auth')

//Create new series
router.post('/series', auth, async (req, res) => {
    const user = req.user
    var series = new Series(req.body)

    if(!user){
        res.status(401).send()
    }

    try {
        series.addedBy = user._id
        await series.save()

        if(req.isAdmin){
            res.status(201).send(series)
        }
    
        else{
            res.status(201).send(req.body)
        }
    }
    catch(e){
        //Add better error handling with the getObjectValue script
        res.status(400).send(e)
    }
})

//Should have some logic here for queries and pagination
router.get('/series', auth, async (req, res) => {
    var series

    try {
        if(req.isAdmin){
            series = await Series.find()
        }
        else{
            series = await Series.find({}, 'name organizer')
        }

        if(!series){
            return res.status(404).send()
        }
        else{
            return res.status(200).send(series)
        }
    } catch (error) {
        console.log(error)
        res.status(400).send()
    }
})

router.get('/series/:name', auth, async (req, res) => {
    var series
    const name = req.params.name

    try {
        if(req.isAdmin){
            series = await Series.findOne({ name })
        }
        else{
            series = await Series.findOne({ name }, 'name organizer')
        }

        if(!series){
            return res.status(404).send()
        }
        else{
            return res.status(200).send(series)
        }
    } catch (error) {
        console.log(error)
        res.status(400).send()
    }
})

router.patch('/series/:name', auth, async (req, res) => {
    const user = req.user
    const updates = Object.keys(req.body)

    if(!user){
        res.status(401).send()
    }

    try {
        const series = await Series.findOne({ name })

        if(!series){
            res.status(404).send()
        }
        

        if(!req.isAdmin || series.addedBy != user._id){
            res.status(403).send()
        }

        updates.forEach((update) => series[update] = req.body[update])

        await series.save()

        res.send(series)
    } catch(errors) {
        console.log(errors)
        res.status(400).send()
    }
})

router.delete('/series/:name', auth, async (req, res) => {
    const user = req.user 
    const name = req.params.name

    if(!user){
        res.status(401).send()
    }

    try {
        const series = await Series.findOneAndDelete({ name })

        if(!series){
            res.status(404).send()
        }
        
        if(!req.isAdmin || series.addedBy != user._id){
            res.status(403).send()
        }

        if(!series){
            res.status(404).send("Cannot find this series to delete")
        }

        res.send(series)
    } catch(error) {
        console.log(error)
        res.status(400).send()
    }
})

module.exports = router