const express = require('express')
const router = new express.Router()
const Battle = require('../models/battle')

router.post('/competitions/:compName-:city-:date/:catName', async (req, res) => {
    try {

    } catch(e) {

    }
})

router.get('/competitions/:compName-:city-:date/:catName/:bracket/:id', async (req, res) => {
    try {

    } catch(e) {

    }
})

router.patch('/competitions/:compName-:city-:date/:catName/:bracket/:id', async (req, res) => {
    try {

    } catch(e) {

    }
})

router.delete('/competitions/:compName-:city-:date/:catName/:bracket/:id', async (req, res) => {
    try {

    } catch(e) {

    }
})

module.exports = router