const mongoose = require('mongoose')
const validator = require('validator')

const categorySchema = new mongoose.Schema({
    style: {
        type: String,
        required: true,
        trim: true
    },
    format: {
        type: String,
        required: true
    },
    competition: {
        type: mongoose.Schema.Types.ObjectId,
        required: true,
        ref: 'Competition'
    },
    date: {
        type: Date,
        required: true
    },
    addedBy: {
        type: mongoose.Schema.Types.ObjectId,
        required: true,
        ref: 'User'
    },
    bracketLayers: {
        type: Number,
        default: 1
    },
    prelimStartLayer: {
        type: Number,
        default: 0
    }
})

const Category = mongoose.model('Category', categorySchema)

module.exports = Category