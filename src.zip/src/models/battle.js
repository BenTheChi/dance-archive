const mongoose = require('mongoose')
const validator = require('validator')

const battleSchema = new mongoose.Schema({
    category: {
        type: String,
        required: true
    },
    competition: {
        type: String,
        required: true
    },
    date: {
        type: Date,
        required: true
    },
    addedBy: {
        type: mongoose.Schema.Types.ObjectId,
        required: true,
        ref: 'User'
    },
    url: {
        type: String,
        required: true,
        validate(value){
            if(!validator.isURL(value)){
                throw new Error('URL is invalid')
            }
        }
    },
    dancers: [{
        dancer: {
            type: String
        } 
    }],
    winner: {
        type: String
    },
    bracket: {
        type: Number,
        required: true,
        validate(value){
            //TODO bracket number cannot be bigger than category bracket layer - 1
        }
    }
})

const Battle = mongoose.model('Battle', battleSchema)

module.exports = Battle