const mongoose = require('mongoose')
const validator = require('validator')

const seriesSchema = new mongoose.Schema({
    name: {
        type: String,
        required: true,
        trim: true
    },
    organizer: {
        type: String,
        trim: true
    },
    addedBy: {
        type: mongoose.Schema.Types.ObjectId,
        required: true,
        ref: 'User'
    }
})

const Series = mongoose.model('Series', seriesSchema)

module.exports = Series