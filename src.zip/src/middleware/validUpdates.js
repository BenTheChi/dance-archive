const validUpdates = (req, res, next) => {
    const path = req.route.path
    const updates = Object.keys(req.body)
    var allowedUpdates = []

    if(path == "/competitions/:city/:name"){
        allowedUpdates = ['name', 'date', 'city', 'dj', 'mc']
    }
    else if(path == "/users/me"){
        allowedUpdates = ['firstName', 'lastName', 'email', 'password', 'age']
    }
    
    req.isValidOperation = updates.every((update) => allowedUpdates.includes(update))
    
    if(!req.isValidOperation){
        return res.status(400).send({ error: 'Invalid updates!'})
    }
    else{
        req.updates = updates
    }

    next()
}

module.exports = validUpdates